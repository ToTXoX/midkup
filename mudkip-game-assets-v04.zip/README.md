# 水跃鱼游戏资源 v0.4

可以直接用于 Three.js 的首版资源包：七段角色骨骼动画、庭院、树果和三种靶子。编辑源文件与浏览器运行文件分开保存。

v0.4 加粗水束、提高喷速，水头和落地水花同步放大；继续使用四道浅蓝轮廓、少量白色高光和四颗散滴。运行时接口说明见 [fx/README.md](fx/README.md)。喷水预览支持慢放。

## 目录

```text
game-assets/
  manifest.json                       # 文件路径、体积、SHA-256、三角面与动画清单
  characters/mudkip/
    mudkip.glb                        # 角色 + 25 根骨骼 + 七段动画 + 两张内嵌贴图
    animations.json                   # 循环、时长、切换、事件与移动速度
  environments/garden.glb             # Meshopt 压缩的静态庭院
  props/
    berry.glb                         # 可单独摆放的树果
    target-normal.glb                 # 普通靶
    target-moving.glb                 # 移动靶主体；轨道保留在庭院
    target-heavy.glb                  # 重型靶
  levels/garden.json                  # 出生点、镜头、靶子布局、22 个基础障碍范围
  fx/water-gun.js                     # 可在 Three.js 中复用的水枪效果
  licenses/                           # Kenney 与 KayKit 原始许可
  CREDITS.md                          # 来源记录
  source/                             # 编辑源与兼容版本，不进入网页运行包
    mudkip-animations.blend
    garden-runtime.blend
    garden-uncompressed.glb
```

单位为米，Three.js 中 `+Y` 向上，角色正面为 `+Z`。树果和靶子原点位于底部；庭院保留统一世界坐标。

## 基础动画

| 名称 | 时长 | 循环 | 行为 |
| --- | --- | --- | --- |
| `Idle` | 3.0 秒 | 是 | 呼吸、头鳍和尾巴轻摆 |
| `Walk` | 0.8 秒 | 是 | 四足错相慢走 |
| `Run` | 0.5 秒 | 是 | 对角足交替的小跑 |
| `PetReaction` | 1.6 秒 | 否 | 蹲身、抬头歪头、摇尾 |
| `Eat` | 1.8 秒 | 否 | 低头、咀嚼、抬头恢复 |
| `WaterCharge` | 1.0 秒 | 是 | 压低身体、准备喷水，可持续保持 |
| `WaterShoot` | 0.7 秒 | 否 | 张嘴、头部轻微后仰、恢复 |

所有动作保持原地。单次动作完成后切回 `Idle`，默认混合 0.22 秒。`WaterShoot` 的起始姿态接近蓄力，结束姿态回到待机，因此不要求它首尾相同。

走路和小跑的代码移动速度分别约为 `0.2621` 和 `0.58` 米/秒；步频变化时同比缩放。速度根据脚掌接地阶段的行程校准，而不是简单用行程除以整段时长。

## 挂点与事件

嘴部挂点为 `Socket_Mouth`，跟随 Head 骨骼，导出后挂点局部 `+Z` 为喷水方向。使用世界位置与世界四元数发射，保证角色转向、抬头时仍对准嘴部。

| 动作 | 时间 | 事件 |
| --- | --- | --- |
| `Eat` | 0.30 秒 | `food_attach`，树果送到嘴边 |
| `Eat` | 0.90 秒 | `food_consume`，隐藏树果 |
| `WaterShoot` | 0.17 秒 | `water_start` |
| `WaterShoot` | 0.46 秒 | `water_stop` |

步伐事件也记录在 `animations.json`。游戏应在动作时间跨过事件时触发一次；循环动作每轮重置，切换或中断时取消旧动作的未触发事件。不要依赖全局计时器追踪动作事件。

预览页使用这些事件显示树果、蓄力水团与水枪，供校对时间。背包扣减、命中与计分尚未接入。

## Three.js 载入

```js
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { MeshoptDecoder } from 'three/addons/libs/meshopt_decoder.module.js';

const loader = new GLTFLoader().setMeshoptDecoder(MeshoptDecoder);
const character = await loader.loadAsync('characters/mudkip/mudkip.glb');
const garden = await loader.loadAsync('environments/garden.glb');
// AnimationMixer 的根节点使用 character.scene。
// 移动包住整个 character.scene 的容器，同时带动骨架与蒙皮。
```

庭院约 2.60 MB，压缩前约 8.85 MB。环境材质已将草地遮罩、树木渐变和程序颜色烘焙为顶点颜色，浏览器保留这些颜色并自行计算光照。水面使用简化的实时材质；Blender 的灯光、雾和水面噪声不随 GLB 自动迁移。

庭院包含 10 个语义分组，因不同材质在 Three.js 中展开为约 50 个渲染网格。静态场景约 15.7 万三角面，尚未进行手机硬件帧率与 LOD 优化。

`levels/garden.json` 提供房屋、树干、栅栏和水池的简化障碍范围，以及保守的可走区域边界。它是后续碰撞与寻路的输入，尚未生成完整导航网格。

## 预览与重建

在 `../animation-test/` 执行 `npm run dev`，打开 <http://127.0.0.1:5173/resources.html>，可切换“动作台”和“庭院总览”。

安装过 Node 依赖后，在项目目录执行：

```powershell
.\scripts\build-game-assets.ps1
```

重建会读取原始角色和已确认的 v11 庭院，生成本目录的资源并同步到测试页。源场景与旧版测试文件保留。

验证命令在 `../animation-test/` 中运行：

```powershell
npm run assets:prepare
npm run test:resources
npm run build
```

浏览器测试需本机 Edge 与已启动的本地测试页。来源及许可见 [CREDITS.md](CREDITS.md)，不同来源的内容保留各自的权利状态。
