import * as THREE from 'three';
import {createPondSimulation} from './pond-simulation.js';

// A shallow, refractive pond with sparse cartoon crests over the heightfield.
export function createPondWater({environment,collider,renderer,scene}){
  const root=environment.getObjectByName('Pond_Water');
  if(!root||!collider)throw new Error('庭院缺少水池表面或边界');
  const box=new THREE.Box3().setFromObject(root),center=box.getCenter(new THREE.Vector3());
  const info={center:[...collider.center],radii:[...collider.radii],height:center.y,inset:.42};
  // Stones were merged during export. Remove complete connected stone islands
  // at the west bank so the entry animation has a real gap, without cut faces.
  let clearedStones=0;
  environment.getObjectByName('Pond_Details')?.traverse(mesh=>{
    if(!mesh.isMesh||!/stones/i.test(mesh.material.name))return;
    const g=mesh.geometry.clone(),p=g.attributes.position,indices=g.index?.array??Uint32Array.from({length:p.count},(_,i)=>i);
    const parents=Array.from({length:p.count},(_,i)=>i),weld=new Map(),v=new THREE.Vector3();
    const find=i=>{while(parents[i]!==i){parents[i]=parents[parents[i]];i=parents[i];}return i;};
    const join=(a,b)=>parents[find(a)]=find(b);
    for(let i=0;i<p.count;i++){v.fromBufferAttribute(p,i);const key=[v.x,v.y,v.z].map(x=>x.toFixed(5)).join(',');if(weld.has(key))join(i,weld.get(key));else weld.set(key,i);}
    for(let i=0;i<indices.length;i+=3){join(indices[i],indices[i+1]);join(indices[i],indices[i+2]);}
    const components=new Map();
    for(let i=0;i<p.count;i++){const id=find(i);if(!components.has(id))components.set(id,new THREE.Box3());components.get(id).expandByPoint(v.fromBufferAttribute(p,i).applyMatrix4(mesh.matrixWorld));}
    const removed=new Set();
    for(const [id,bounds] of components){const c=bounds.getCenter(v);if(c.x<info.center[0]-info.radii[0]*.72&&Math.abs(c.z-info.center[1])<.7){removed.add(id);clearedStones++;}}
    const kept=[];for(let i=0;i<indices.length;i+=3)if(!removed.has(find(indices[i])))kept.push(indices[i],indices[i+1],indices[i+2]);
    g.setIndex(kept);mesh.geometry=g;
  });
  const simulation=createPondSimulation(renderer,{...info,size:innerWidth<700?64:96});
  const crests=Array.from({length:3},()=>new THREE.Vector4(0,0,-100,0));
  const refraction=new THREE.WebGLRenderTarget(512,512,{depthBuffer:true});
  refraction.depthTexture=new THREE.DepthTexture(512,512,THREE.UnsignedIntType);
  const uniforms={uTime:{value:0},uCenter:{value:new THREE.Vector2(...info.center)},uRadii:{value:new THREE.Vector2(...info.radii)},uCrests:{value:crests},uState:{value:simulation.texture},uGrid:{value:simulation.debug().size},uScene:{value:refraction.texture},uDepth:{value:refraction.depthTexture},uResolution:{value:new THREE.Vector2()},uNear:{value:.05},uFar:{value:100},uShallow:{value:new THREE.Color('#9bcdbd')},uDeep:{value:new THREE.Color('#609fa8')}};
  uniforms.uBody={value:new THREE.Vector4(0,0,0,0)};uniforms.uStroke={value:0};
  const sampling=`uniform sampler2D uState;uniform float uGrid;
    vec4 stateAt(vec2 uv){vec2 q=uv*uGrid-.5,f=fract(q),base=(floor(q)+.5)/uGrid;
      return mix(mix(texture2D(uState,base),texture2D(uState,base+vec2(1./uGrid,0.)),f.x),
      mix(texture2D(uState,base+vec2(0.,1./uGrid)),texture2D(uState,base+vec2(1./uGrid)),f.x),f.y);}`;
  const material=new THREE.ShaderMaterial({name:'Heightfield cartoon pond',uniforms,side:THREE.DoubleSide,
    vertexShader:`${sampling} uniform vec2 uCenter,uRadii;varying vec3 vWorld;varying float vDepth;
      void main(){vec4 world=modelMatrix*vec4(position,1.);vec2 uv=(world.xz-uCenter)/(2.*uRadii)+.5;
        world.y+=stateAt(uv).r;vWorld=world.xyz;vec4 view=viewMatrix*world;vDepth=-view.z;gl_Position=projectionMatrix*view;}`,
    fragmentShader:`${sampling}
      uniform float uTime,uNear,uFar;uniform vec2 uCenter,uRadii,uResolution;
      uniform vec4 uCrests[3];
      uniform vec4 uBody;uniform float uStroke;
      uniform sampler2D uScene,uDepth;uniform vec3 uShallow,uDeep;varying vec3 vWorld;varying float vDepth;
      float viewDepth(float depth){return uNear*uFar/(uFar-depth*(uFar-uNear));}
      void main(){
        vec2 uv=(vWorld.xz-uCenter)/(2.*uRadii)+.5;vec4 state=stateAt(uv);
        vec2 slope=clamp(state.ba,vec2(-.45),vec2(.45));
        // A millimeter-scale background breeze, not painted foam ribbons.
        slope+=vec2(cos(vWorld.x*5.+uTime*.65),sin(vWorld.z*4.-uTime*.48))*.003;
        vec3 normal=normalize(vec3(slope.x,sqrt(max(.01,1.-dot(slope,slope))),slope.y));
        vec3 eye=normalize(cameraPosition-vWorld);vec2 screen=gl_FragCoord.xy/uResolution;
        float thickness=max(0.,viewDepth(texture2D(uDepth,screen).r)-vDepth);
        vec2 offset=(mat3(viewMatrix)*normal).xy*.022*min(thickness,.35);
        vec2 refracted=clamp(screen+offset,vec2(.001),vec2(.999));
        if(viewDepth(texture2D(uDepth,refracted).r)<vDepth)refracted=screen;
        vec3 underneath=texture2D(uScene,refracted).rgb;
        vec3 tint=mix(uShallow,uDeep,smoothstep(.04,.42,thickness));
        float absorption=1.-exp(-thickness*2.5);
        vec3 color=mix(underneath*vec3(.70,.93,.98),tint,.42+absorption*.28);
        vec3 reflection=mix(vec3(.36,.51,.40),vec3(.78,.88,.83),smoothstep(.02,.7,reflect(-eye,normal).y));
        float fresnel=.09+.45*pow(1.-max(dot(eye,normal),0.),4.);
        color=mix(color,reflection,fresnel);
        color+=vec3(.65,.85,.85)*clamp(dot(state.ba,vec2(-.6,.8)),-.12,.12)*.16;
        vec3 light=normalize(vec3(-.5,1.,.6)),halfway=normalize(light+eye);
        float glint=pow(max(dot(normal,halfway),0.),100.);
        color+=vec3(.90,.96,.87)*glint*.06;
        // At most three broad, broken crests. Leave gaps and vary thickness so
        // these read as small white waves, rather than complete indicator rings.
        float shore=1.-smoothstep(.88,.99,length(uv*2.-1.));
        for(int i=0;i<3;i++){
          vec4 crest=uCrests[i];float age=uTime-crest.z;
          if(age>=0.&&age<1.35){
            vec2 relative=vWorld.xz-crest.xy,forward=vec2(sin(crest.w),cos(crest.w));
            vec2 local=vec2(dot(relative,vec2(forward.y,-forward.x)),dot(relative,forward));
            vec2 radii=vec2(.29+age*.34,.37+age*.38);
            float angle=atan(local.x/radii.x,local.y/radii.y);
            float contour=(length(local/radii)-1.)*radii.x;
            contour+=.021*sin(angle*5.+age*2.)+.009*sin(angle*9.-age*3.);
            float width=mix(.020,.011,age/1.35)*(1.+.20*sin(angle*3.+age));
            float aa=max(fwidth(contour),.002);
            float edge=1.-smoothstep(width,width+aa,abs(contour));
            float arc=smoothstep(-.35,.05,cos(angle))*smoothstep(-.15,.35,sin(angle*5.+.7));
            float tail=.40*smoothstep(.55,.85,-cos(angle))*smoothstep(.15,.65,sin(angle*4.-.4));
            float life=smoothstep(0.,.09,age)*(1.-smoothstep(.60,1.35,age));
            float swell=exp(-pow(contour/.060,2.))*.12;
            color=mix(color,vec3(.69,.86,.80),swell*life*shore);
            color=mix(color,vec3(.91,.98,.93),edge*max(arc,tail)*life*shore*.88);
          }
        }
        if(uBody.w>.01){
          vec2 relative=vWorld.xz-uBody.xy,forward=vec2(sin(uBody.z),cos(uBody.z));
          vec2 local=vec2(dot(relative,vec2(forward.y,-forward.x)),dot(relative,forward));
          float phase=uStroke*6.28318+(local.x<0.?3.14159:0.);
          float push=.50+.50*sin(phase);
          float side=abs(local.x),curve=.25+.025*sin((local.y+.05)*11.+push*.4);
          float scallop=.007*sin(local.y*48.+phase);
          float cap=(1.-smoothstep(.012,.022,abs(side-curve+scallop)))
            *smoothstep(-.23,-.12,local.y)*(1.-smoothstep(.09,.19,local.y));
          float bead=1.-smoothstep(.022,.032,length(vec2(side-.285,local.y+.085)));
          float foam=max(cap,bead*.8)*(.45+.55*push)*uBody.w*shore;
          color=mix(color,vec3(.94,.99,.96),foam*.90);
        }
        gl_FragColor=vec4(color,1.);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`});
  material.userData.outlineParameters={visible:false};
  // Subdivide the original flat fan so simulated height changes move the surface.
  const positions=[],indices=[],rings=40,segments=112;
  for(let i=0;i<=rings;i++)for(let j=0;j<segments;j++){const r=i/rings,a=j/segments*Math.PI*2;positions.push(info.center[0]+r*info.radii[0]*Math.cos(a),info.height,info.center[1]+r*info.radii[1]*Math.sin(a));}
  for(let i=0;i<rings;i++)for(let j=0;j<segments;j++){const a=i*segments+j,b=i*segments+(j+1)%segments,c=a+segments,d=b+segments;indices.push(a,b,c,b,d,c);}
  const surfaceGeometry=new THREE.BufferGeometry();surfaceGeometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));surfaceGeometry.setIndex(indices);surfaceGeometry.computeVertexNormals();
  root.traverse(o=>{if(o.isMesh){o.geometry=surfaceGeometry;o.material=material;o.castShadow=false;o.receiveShadow=false;o.renderOrder=2;}});
  // Replace the baked, immobile white loops. Keep stones and lily pads.
  environment.traverse(o=>{if(o.isMesh&&[].concat(o.material).some(m=>/water ripple/i.test(m.name)))o.visible=false;});

  const drops=new THREE.Group();drops.name='Pond entry droplets';environment.add(drops);
  const geometry=new THREE.SphereGeometry(.011,6,4),dropMaterial=new THREE.MeshBasicMaterial({color:'#d9f5e9',transparent:true,depthWrite:false});
  dropMaterial.userData.outlineParameters={visible:false};
  const particles=Array.from({length:4},()=>{const mesh=new THREE.Mesh(geometry,dropMaterial);mesh.visible=false;mesh.renderOrder=3;mesh.userData.combatDecoration=true;drops.add(mesh);return {mesh,origin:new THREE.Vector3(),velocity:new THREE.Vector3(),born:-100};});
  let time=0,crestIndex=0,lastCrest=-100,travelSinceCrest=0,foamStrength=0;
  const previousBody=new THREE.Vector3();let hadBody=false;
  function crest(point,yaw=0){crests[crestIndex++%crests.length].set(point.x,point.z,time,yaw);lastCrest=time;}
  function ripple(point,strength=.4){simulation.drop(point,.002*strength,.15);crest(point);}
  function splash(point){
    ripple(point,1);
    particles.forEach((p,i)=>{const angle=i/particles.length*Math.PI*2;p.born=time;p.origin.set(point.x,info.height+.008,point.z);p.velocity.set(Math.cos(angle)*(.10+i%2*.03),.30+i%2*.06,Math.sin(angle)*(.10+i%2*.03));});
  }
  function update(delta,{contacts,inWater=false,moving=false,stroke=0}={}){
    time+=delta;uniforms.uTime.value=time;
    simulation.update(delta,inWater?contacts:null);uniforms.uState.value=simulation.texture;
    foamStrength=THREE.MathUtils.damp(foamStrength,inWater&&moving?1:0,10,delta);
    uniforms.uBody.value.w=foamStrength;uniforms.uStroke.value=stroke;
    if(contacts){const [body,head]=contacts;uniforms.uBody.value.set((body.x+head.x)/2,(body.z+head.z)/2,Math.atan2(head.x-body.x,head.z-body.z),foamStrength);}
    if(inWater&&contacts&&delta>0){
      const body=contacts[0],head=contacts[1],distance=hadBody?Math.hypot(body.x-previousBody.x,body.z-previousBody.z):0;
      if(distance<.15)travelSinceCrest+=distance;
      if(hadBody&&time-lastCrest>.72&&travelSinceCrest>.10&&distance/delta>.12){
        crest(body,Math.atan2(head.x-body.x,head.z-body.z));travelSinceCrest=0;
      }
      previousBody.copy(body);hadBody=true;
    }else if(!inWater){hadBody=false;travelSinceCrest=0;}
    particles.forEach(p=>{const age=time-p.born;p.mesh.visible=age>=0&&age<.6;if(!p.mesh.visible)return;p.mesh.position.copy(p.origin).addScaledVector(p.velocity,age);p.mesh.position.y-=1.6*age*age;p.mesh.scale.set(.75,1.3,.75).multiplyScalar(1-age/.6);if(p.mesh.position.y<info.height)p.mesh.visible=false;});
  }
  function reset(){simulation.reset();uniforms.uState.value=simulation.texture;particles.forEach(p=>{p.born=-100;p.mesh.visible=false;});crests.forEach(c=>c.z=-100);crestIndex=0;lastCrest=-100;hadBody=false;travelSinceCrest=0;foamStrength=uniforms.uBody.value.w=0;}
  const drawingBuffer=new THREE.Vector2();
  function prepare(camera){
    renderer.getDrawingBufferSize(drawingBuffer);uniforms.uResolution.value.copy(drawingBuffer);
    const scale=Math.min(.65,960/drawingBuffer.x),w=Math.max(1,Math.round(drawingBuffer.x*scale)),h=Math.max(1,Math.round(drawingBuffer.y*scale));
    if(refraction.width!==w||refraction.height!==h)refraction.setSize(w,h);
    uniforms.uNear.value=camera.near;uniforms.uFar.value=camera.far;
    const target=renderer.getRenderTarget(),shadowAuto=renderer.shadowMap.autoUpdate,shadowEnabled=renderer.shadowMap.enabled;
    root.visible=false;drops.visible=false;renderer.shadowMap.autoUpdate=false;renderer.shadowMap.enabled=false;
    try{renderer.setRenderTarget(refraction);renderer.render(scene,camera);}finally{renderer.setRenderTarget(target);renderer.shadowMap.autoUpdate=shadowAuto;renderer.shadowMap.enabled=shadowEnabled;root.visible=true;drops.visible=true;}
  }
  return {info,update,ripple,splash,reset,prepare,sampleWaves:simulation.sample,debug:()=>({time,height:info.height,center:info.center,radii:info.radii,clearedStones,ripples:crests.filter(c=>time-c.z<1.35).length,crestLimit:crests.length,crestInterval:.72,foam:foamStrength,droplets:particles.filter(p=>p.mesh.visible).length,shader:'heightfield-refractive-toon',simulation:simulation.debug(),extraRenderTargets:3,refractionSize:[refraction.width,refraction.height]})};
}
