# 水跃鱼游戏资源 v0.10

可以直接用于 Three.js 的首版资源包：七段角色骨骼动画、庭院、树果和三种靶子。编辑源文件与浏览器运行文件分开保存。

v0.10 用右下角独立水枪技能键统一电脑与手机操作：无目标时点按朝面前喷水，按住拖动自由选择方向，松开发射；点靶子可选锁定，再点技能键命中。草地始终用于移动，界面不再提供移动／瞄准模式切换。技能键在准备、喷水和恢复阶段显示状态；触控捕获、取消、暂停及场景切换均已接入。

v0.9 接通瞄准、水枪与命中反馈：点击靶子锁定、转身抬头、闭嘴蓄水，按空格或屏幕按钮发射；也可在瞄准模式下点击草地自由喷水。水流按真实弧线与庭院网格碰撞，第一股水抵达靶面后才计一次命中。靶面回弹、水色闪光、短促水花和「命中 +1」共同反馈结果，支持手机触控。此次只修改 Three.js 逻辑，角色与庭院模型继续使用 v0.8 / v11 的源文件。

v0.8 重做走路与跑步：加大步幅和抬脚、加入跑步蹬地与短暂腾空、头鳍与尾鳍滞后摆动，并将地面速度提升至约 0.66 / 1.54 米每秒。移动加入加减速、转弯倾斜与停步回正。落点改为白边薄荷绿圆环，随点击扩散、到达收拢，不显示路径线。入口为 `resources.html?scene=garden`，接入说明见 [gameplay/README.md](gameplay/README.md)。

## 目录

```text
game-assets/
  manifest.json                       # 文件路径、体积、SHA-256、三角面与动画清单
  characters/mudkip/
    mudkip.glb                        # 角色 + 25 根骨骼 + 七段动画 + 两张内嵌贴图
    animations.json                   # 循环、时长、切换、事件与移动速度
  environments/garden.glb             # Meshopt 压缩的静态庭院
  props/
    berry.glb                         # 可单独摆放的树果
    target-normal.glb                 # 普通靶
    target-moving.glb                 # 移动靶主体；轨道保留在庭院
    target-heavy.glb                  # 重型靶
  levels/garden.json                  # 出生点、镜头、靶子布局、22 个基础障碍范围
  fx/water-gun.js                     # 可在 Three.js 中复用的水枪效果
  rendering/toon-style.js              # 三渲二材质、配光与骨骼轮廓线
  rendering/README.md                  # Three.js 接入方式与 Blender 材质说明
  gameplay/garden-navigation.js        # 碰撞、A* 寻路与路径跟随
  gameplay/destination-marker.js       # 屏幕尺寸稳定的落点圆环
  gameplay/water-aim.js                # 与水流一致的低弧线瞄准解算
  gameplay/garden-combat.js            # 瞄准、转向、施法与命中状态
  gameplay/target-feedback.js          # 靶面回弹、命中闪光与计数
  gameplay/water-skill-input.js        # 技能键的点按、拖动与触控取消
  gameplay/README.md                   # 移动与水枪模块接入说明
  licenses/                           # Kenney 与 KayKit 原始许可
  CREDITS.md                          # 来源记录
  source/                             # 编辑源与兼容版本，不进入网页运行包
    mudkip-animations.blend
    garden-runtime.blend
    garden-uncompressed.glb
```

单位为米，Three.js 中 `+Y` 向上，角色正面为 `+Z`。树果和靶子原点位于底部；庭院保留统一世界坐标。

## 基础动画

| 名称 | 时长 | 循环 | 行为 |
| --- | --- | --- | --- |
| `Idle` | 3.0 秒 | 是 | 闭嘴呼吸、头鳍和尾巴轻摆 |
| `Walk` | 0.5 秒 | 是 | 四足错相、轻快抬脚、身体轻摆 |
| `Run` | 0.4 秒 | 是 | 对角足蹬地、短暂腾空、头尾滞后回弹 |
| `PetReaction` | 1.6 秒 | 否 | 蹲身、抬头歪头、摇尾 |
| `Eat` | 1.8 秒 | 否 | 低头、咀嚼、抬头恢复 |
| `WaterCharge` | 1.0 秒 | 是 | 闭嘴压低身体、准备喷水，可持续保持 |
| `WaterShoot` | 1.0 秒 | 否 | 闭嘴蓄力、张嘴发射、合嘴恢复 |

所有动作保持原地。单次动作完成后切回 `Idle`，默认混合 0.22 秒，移动动作的混合为 0.12 秒。`WaterShoot` 自带准备动作，直接播放也会先闭嘴蓄力，首尾回到闭嘴待机姿态。

喷水分段：0–0.23 秒闭嘴蹲身；0.23–0.33 秒快速张嘴；0.33–0.66 秒出水；0.68–0.90 秒合嘴；最后恢复站姿。原模型的静置嘴型为张嘴，通过 Jaw 骨骼约 -0.37 弧度闭合，未修改原始网格和贴图。摸头与进食仍在动作中适当张嘴，结束后合嘴。

走路和小跑的代码移动速度分别约为 `0.6607` 和 `1.5441` 米/秒，约为上一版的 2.52 / 2.66 倍。速度根据脚掌接地阶段的行程校准；加减速时，动作播放速率也随实际速度改变。关节以 120 FPS 烘焙，改善接地阶段的插值，浏览器播放不要求 120 FPS。

## 挂点与事件

嘴部挂点为 `Socket_Mouth`，跟随 Head 骨骼，导出后挂点局部 `+Z` 为喷水方向。使用世界位置与世界四元数发射，保证角色转向、抬头时仍对准嘴部。

| 动作 | 时间 | 事件 |
| --- | --- | --- |
| `Eat` | 0.30 秒 | `food_attach`，树果送到嘴边 |
| `Eat` | 0.90 秒 | `food_consume`，隐藏树果 |
| `WaterShoot` | 0.33 秒 | `water_start` |
| `WaterShoot` | 0.66 秒 | `water_stop` |

步伐事件也记录在 `animations.json`。游戏应在动作时间跨过事件时触发一次；循环动作每轮重置，切换或中断时取消旧动作的未触发事件。不要依赖全局计时器追踪动作事件。

预览页使用这些事件显示树果与水枪，供校对时间。蓄力时嘴外不显示水团；起喷水珠只在张嘴末段出现。背包扣减、命中与计分尚未接入。

## Three.js 载入

```js
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { MeshoptDecoder } from 'three/addons/libs/meshopt_decoder.module.js';

const loader = new GLTFLoader().setMeshoptDecoder(MeshoptDecoder);
const character = await loader.loadAsync('characters/mudkip/mudkip.glb');
const garden = await loader.loadAsync('environments/garden.glb');
// AnimationMixer 的根节点使用 character.scene。
// 移动包住整个 character.scene 的容器，同时带动骨架与蒙皮。
```

庭院约 2.60 MB，压缩前约 8.85 MB。环境材质已将草地遮罩、树木渐变和程序颜色烘焙为顶点颜色，浏览器保留这些颜色并自行计算光照。水面使用简化的实时材质；Blender 的灯光、雾和水面噪声不随 GLB 自动迁移。

角色源文件 `source/mudkip-animations.blend` 已配置 Eevee 三档明暗与可随骨架变形的描边壳；项目根目录另有便于直接打开的 `mudkip-toon-v08.blend`。GLB 保留原始可移植贴图与动画，网页加载后调用 `rendering/toon-style.js` 应用动画材质。描边壳不进入 GLB，避免重复描边。

庭院包含 10 个语义分组，因不同材质在 Three.js 中展开为约 50 个渲染网格。静态场景约 15.7 万三角面，尚未进行手机硬件帧率与 LOD 优化。

`levels/garden.json` 提供房屋、树干、栅栏和水池的简化障碍范围、可走区域边界与角色占地设置。`gameplay/garden-navigation.js` 使用这些数据进行碰撞与网格寻路；靶子和树果篮在测试页补充占地。

## 预览与重建

在 `../animation-test/` 执行 `npm run dev`，打开 <http://127.0.0.1:5173/resources.html>，可切换“动作台”和“庭院总览”。

安装过 Node 依赖后，在项目目录执行：

```powershell
.\scripts\build-game-assets.ps1
```

重建会读取原始角色和已确认的 v11 庭院，生成本目录的资源并同步到测试页。源场景与旧版测试文件保留。

验证命令在 `../animation-test/` 中运行：

```powershell
npm run assets:prepare
npm run test:resources
npm run build
```

浏览器测试需本机 Edge 与已启动的本地测试页。来源及许可见 [CREDITS.md](CREDITS.md)，不同来源的内容保留各自的权利状态。
