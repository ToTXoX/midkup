# 水枪效果 v0.5

## 水池效果 v0.12

`pond-water.js` 导出 `createPondWater({environment,collider})`，用于本庭院导出的 Pond_Water / Pond_Details 网格。调用时需先完成环境世界矩阵更新和 toon 材质转换。初始化替换静态水面材质、隐藏旧波纹并移除西岸两颗石头，保留真正的进出缺口。

每帧调用 `update(delta,{position,yaw,inWater,moving})`，在入水或命中水面时调用 `splash(worldPoint)`。`ripple(worldPoint,strength)` 可以单独触发涟漪；暂停时 delta=0，场景切换时 reset。info 包含水面高度与游泳边界数据。采用径向浅盆近似、透明混合、轻量高光与复用水滴，不需要额外贴图、反射相机或 WebGPU。

## 水枪

`water-gun.js` 为 Three.js ESM 模块，依赖宿主项目安装的 `three`。源文件位于 `animation-test/src/water-gun-effect.js`，执行 `npm run assets:prepare` 时复制到本资源包。

效果包括嘴边的起喷水珠、具有粗细起伏的弧形水体、圆润水头、断流后三段余水、七个飞行水滴、四道简洁的卡通水花、四颗溅射水滴、两道淡水纹与短暂湿斑。

v0.4 将水束主体直径加粗至约三倍、喷速从 5 提高至 9 米/秒，并同步放大水头和散滴；落地水花放大 1.55 倍。嘴边采用细水颈，再逐渐展开为较粗的中前段。配色为低饱和浅青灰与白色高光，保持通透和简洁。

落地水花使用浅蓝轮廓和少量白色内弧，四道不等大的水花分两拍快速展开；每道约 0.21 秒后消散，只留下淡水纹。形状具有少量厚度，可以在三维场景中旋转查看。所有形状均在初始化时生成，播放时只改变位置、比例和透明度。

所有几何体和材质创建后复用。不会在每次发射时增加新的 Mesh，也不使用异步计时器；通过动作时间驱动，可以暂停和反向拖动预览。

v0.5 与角色一秒的闭嘴蓄力动作同步：0.33 秒开始出水、0.66 秒停水，水珠在开始前 0.025 秒随张嘴出现。蓄力阶段没有嘴外水团。

v0.9 庭院游戏可调用 `begin(null,null,{defer:true})`，使弹道在第一次 `update()` 到达出水时间时初始化。此时应传入真实嘴部位置和 `solveWaterAim()` 的方向，准备动作不会影响发射瞄准。碰撞回调可额外返回 `targetId`，模块会在 `debug()` 中携带该编号、`firstImpact`、`impactPoint` 和 `time`；宿主仅在第一股水到达时按本发编号计一次命中。原先逐帧预览接口保持可用。

## 接口

```js
import { createWaterGunEffect } from './fx/water-gun.js';

const fx = createWaterGunEffect({
  scene,
  start: 0.33,
  stop: 0.66,
  actionDuration: 1.0,
  resolveImpact(origin, velocity, gravity) {
    // 沿 p(t) = origin + velocity*t - (0, gravity*t*t/2, 0)
    // 和场景碰撞求得首次接触。
    // point、normal 均使用世界坐标，normal 必须归一化。
    return { time: flightTime, point: hitPoint, normal: hitNormal };
  },
});

// 播放 WaterShoot 时调用一次。forward 为嘴部挂点的世界 +Z 方向。
fx.begin(mouthPosition, forward);

// 水枪动作期间每帧更新。actionTime 为动作的局部时间。
fx.update(actionTime, mouthPosition, forward);

// 动作自然结束，角色转回 Idle；保留已喷出的水和落点余波。
fx.finish();
// 后续每帧运行；暂停时 deltaSeconds=0，慢放时同比缩放 delta。
fx.updateTail(deltaSeconds);

// 用户打断动作、切换场景或重新开始时清理旧效果。
fx.cancel();
// 卸载场景时释放资源。
fx.dispose();
```

`start`、`stop`、`actionDuration` 应从 `characters/mudkip/animations.json` 中的 WaterShoot 配置读取。

水流从世界嘴部位置出发，沿发射方向飞行后受到重力下落。撞击水冠、薄水膜、湿斑和水纹按接触表面法线对齐。此模块提供视觉表现，命中扣分、受击、目标选择等游戏规则由宿主负责。

材质使用浅青蓝主体、较深边缘、少量白色高光与半透明混合，包含 Three.js 的色调映射和颜色输出转换。无需额外图片、HDR 或粒子贴图。
