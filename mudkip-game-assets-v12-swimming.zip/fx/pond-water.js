import * as THREE from 'three';

// Small shallow basin: analytic depth avoids extra scene/reflection passes on phones.
// Design references (concepts only): roystan.net/articles/toon-water/ and Three.js Water2.
export function createPondWater({environment,collider}){
  const root=environment.getObjectByName('Pond_Water');
  if(!root||!collider)throw new Error('庭院缺少水池表面或边界');
  const box=new THREE.Box3().setFromObject(root),center=box.getCenter(new THREE.Vector3());
  const info={center:[...collider.center],radii:[...collider.radii],height:center.y,inset:.42};
  // Stones were merged during export. Remove complete connected stone islands
  // at the west bank so the entry animation has a real gap, without cut faces.
  let clearedStones=0;
  environment.getObjectByName('Pond_Details')?.traverse(mesh=>{
    if(!mesh.isMesh||!/stones/i.test(mesh.material.name))return;
    const g=mesh.geometry.clone(),p=g.attributes.position,indices=g.index?.array??Uint32Array.from({length:p.count},(_,i)=>i);
    const parents=Array.from({length:p.count},(_,i)=>i),weld=new Map(),v=new THREE.Vector3();
    const find=i=>{while(parents[i]!==i){parents[i]=parents[parents[i]];i=parents[i];}return i;};
    const join=(a,b)=>parents[find(a)]=find(b);
    for(let i=0;i<p.count;i++){v.fromBufferAttribute(p,i);const key=[v.x,v.y,v.z].map(x=>x.toFixed(5)).join(',');if(weld.has(key))join(i,weld.get(key));else weld.set(key,i);}
    for(let i=0;i<indices.length;i+=3){join(indices[i],indices[i+1]);join(indices[i],indices[i+2]);}
    const components=new Map();
    for(let i=0;i<p.count;i++){const id=find(i);if(!components.has(id))components.set(id,new THREE.Box3());components.get(id).expandByPoint(v.fromBufferAttribute(p,i).applyMatrix4(mesh.matrixWorld));}
    const removed=new Set();
    for(const [id,bounds] of components){const c=bounds.getCenter(v);if(c.x<info.center[0]-info.radii[0]*.72&&Math.abs(c.z-info.center[1])<.7){removed.add(id);clearedStones++;}}
    const kept=[];for(let i=0;i<indices.length;i+=3)if(!removed.has(find(indices[i])))kept.push(indices[i],indices[i+1],indices[i+2]);
    g.setIndex(kept);mesh.geometry=g;
  });
  const ripples=Array.from({length:12},()=>new THREE.Vector4(0,0,-100,0));
  const uniforms={uTime:{value:0},uCenter:{value:new THREE.Vector2(...info.center)},uRadii:{value:new THREE.Vector2(...info.radii)},uRipples:{value:ripples},uSwimmer:{value:new THREE.Vector4(0,0,0,0)},uShallow:{value:new THREE.Color('#a6ded0')},uDeep:{value:new THREE.Color('#5aaeb5')},uFoam:{value:new THREE.Color('#effff1')}};
  const material=new THREE.ShaderMaterial({name:'Anime shallow pond',uniforms,transparent:true,depthWrite:true,side:THREE.DoubleSide,
    vertexShader:`varying vec3 vWorld;
      void main(){vec4 world=modelMatrix*vec4(position,1.);vWorld=world.xyz;gl_Position=projectionMatrix*viewMatrix*world;}`,
    fragmentShader:`uniform float uTime;uniform vec2 uCenter,uRadii;uniform vec4 uRipples[12],uSwimmer;
      uniform vec3 uShallow,uDeep,uFoam;varying vec3 vWorld;
      float band(float x,float width){return 1.-smoothstep(width,width+max(fwidth(x),.004),abs(x));}
      void main(){
        vec2 p=vWorld.xz-uCenter,uv=p/uRadii;float r=length(uv);
        float depth=1.-smoothstep(.30,1.,r);
        float drift=sin(p.x*5.+uTime*.65)+sin(p.y*4.-uTime*.48);
        vec3 color=mix(uShallow,uDeep,smoothstep(.05,.85,depth)*.85);
        // Broad, quiet sky reflections, with soft bands rather than metallic noise.
        float reflection=smoothstep(.45,.8,sin(p.y*3.+p.x*.7+drift*.16+uTime*.22));
        color=mix(color,vec3(.76,.91,.85),reflection*.12);
        vec2 flow=p*7.+vec2(uTime*.16,-uTime*.12);
        flow+=vec2(sin(flow.y*.8+uTime*.25),sin(flow.x*.7-uTime*.3))*.4;
        float caustic=band(sin(flow.x+sin(flow.y))*.55+sin(flow.y)*.45,.035);
        color=mix(color,uFoam,caustic*.11*depth);
        float edge=.925+.012*sin(atan(uv.y,uv.x)*9.+uTime*.85);
        float foam=band(r-edge,.009)*(.35+.65*smoothstep(-.2,.6,sin(p.y*8.+p.x*6.+uTime*.45)));
        float ribbon=band(sin(p.x*4.+p.y*6.+drift*.35-uTime*.55)-.93,.012);
        color=mix(color,uFoam,foam*.68+ribbon*.16*(1.-smoothstep(.65,.95,r)));
        for(int i=0;i<12;i++){
          vec4 wave=uRipples[i];float age=uTime-wave.z;
          if(age>=0.&&age<1.4){
            float d=length(vWorld.xz-wave.xy),radius=.045+age*(.32+wave.w*.12);
            float ring=band(d-radius,.008+age*.004)*(1.-age/1.4);
            color=mix(color,uFoam,ring*.65*(1.-smoothstep(.88,1.,r)));
          }
        }
        vec3 eye=normalize(cameraPosition-vWorld);
        if(uSwimmer.w>.01){
          vec2 relative=vWorld.xz-uSwimmer.xy,forward=vec2(sin(uSwimmer.z),cos(uSwimmer.z));
          vec2 local=vec2(dot(relative,vec2(forward.y,-forward.x)),dot(relative,forward));
          float wake=band(abs(local.x)-(-local.y*.42+.13),.009)*smoothstep(0.,.10,-local.y)*(1.-smoothstep(.18,.68,-local.y));
          color=mix(color,uFoam,wake*uSwimmer.w*.65*(1.-smoothstep(.90,1.,r)));
        }
        float fresnel=pow(1.-max(eye.y,0.),3.);
        color=mix(color,vec3(.84,.94,.88),fresnel*.22);
        gl_FragColor=vec4(color,mix(.72,.93,depth));
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`});
  material.userData.outlineParameters={visible:false};
  root.traverse(o=>{if(o.isMesh){o.material=material;o.castShadow=false;o.receiveShadow=false;o.renderOrder=2;}});
  // Replace the baked, immobile white loops. Keep stones and lily pads.
  environment.traverse(o=>{if(o.isMesh&&[].concat(o.material).some(m=>/water ripple/i.test(m.name)))o.visible=false;});

  const drops=new THREE.Group();drops.name='Pond entry droplets';environment.add(drops);
  const geometry=new THREE.SphereGeometry(.018,6,4),dropMaterial=new THREE.MeshBasicMaterial({color:'#d9f5e9',transparent:true,depthWrite:false});
  dropMaterial.userData.outlineParameters={visible:false};
  const particles=Array.from({length:10},()=>{const mesh=new THREE.Mesh(geometry,dropMaterial);mesh.visible=false;mesh.renderOrder=3;mesh.userData.combatDecoration=true;drops.add(mesh);return {mesh,origin:new THREE.Vector3(),velocity:new THREE.Vector3(),born:-100};});
  let time=0,index=0,sinceWake=0,lastX=null,lastZ=null;
  function ripple(point,strength=.4){const wave=ripples[index++%ripples.length];wave.set(point.x,point.z,time,strength);}
  function splash(point){
    ripple(point,1);
    particles.forEach((p,i)=>{const angle=i/particles.length*Math.PI*2;p.born=time;p.origin.set(point.x,info.height+.012,point.z);p.velocity.set(Math.cos(angle)*(.18+i%3*.08),.65+i%3*.12,Math.sin(angle)*(.18+i%3*.08));});
  }
  function update(delta,{position,yaw=0,inWater=false,moving=false}={}){
    time+=delta;uniforms.uTime.value=time;
    if(position)uniforms.uSwimmer.value.set(position.x,position.z,yaw,inWater&&moving?1:0);
    if(inWater&&position){
      const distance=lastX===null?0:Math.hypot(position.x-lastX,position.z-lastZ);
      sinceWake+=delta;
      if(sinceWake>(moving?.17:1.05)&&delta>0){ripple(position,moving?.6:.15);sinceWake=0;}
      if(distance>.4)sinceWake=0;
      lastX=position.x;lastZ=position.z;
    }else{lastX=lastZ=null;sinceWake=0;}
    particles.forEach(p=>{const age=time-p.born;p.mesh.visible=age>=0&&age<.6;if(!p.mesh.visible)return;p.mesh.position.copy(p.origin).addScaledVector(p.velocity,age);p.mesh.position.y-=1.6*age*age;p.mesh.scale.set(.75,1.3,.75).multiplyScalar(1-age/.6);if(p.mesh.position.y<info.height)p.mesh.visible=false;});
  }
  function reset(){ripples.forEach(r=>r.z=-100);particles.forEach(p=>{p.born=-100;p.mesh.visible=false;});sinceWake=0;lastX=lastZ=null;}
  return {info,update,ripple,splash,reset,debug:()=>({time,height:info.height,center:info.center,radii:info.radii,clearedStones,ripples:ripples.filter(r=>time-r.z<1.4).length,droplets:particles.filter(p=>p.mesh.visible).length,shader:'toon-shallow-pond',extraRenderTargets:0})};
}
