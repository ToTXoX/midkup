import * as THREE from 'three';

export function createGardenSwimming({actor,pond,walkTo,isWalking,groundHeight,onClip,canAnimate,onStop,onMessage,onSplash}){
  const [cx,cz]=pond.center,[rx,rz]=pond.radii;
  const entry={land:new THREE.Vector3(cx-rx-.60,0,cz),water:new THREE.Vector3(cx-(rx-pond.inset)*.7,0,cz)};
  entry.land.y=(groundHeight(entry.land.x,entry.land.z)??0)+.005;
  const waterY=pond.height-.16;
  entry.water.y=waterY;
  const up=new THREE.Vector3(0,1,0),desired=new THREE.Quaternion();
  let phase='land',goal=null,afterExit=null,progress=0,clock=0,speed=0,start=new THREE.Vector3(),splashSent=false;
  const contains=p=>((p.x-cx)/rx)**2+((p.z-cz)/rz)**2<=1.08**2;
  function clampGoal(p){const q=new THREE.Vector2((p.x-cx)/(rx-pond.inset),(p.z-cz)/(rz-pond.inset));if(q.length()>1)q.normalize();return new THREE.Vector3(cx+q.x*(rx-pond.inset),waterY,cz+q.y*(rz-pond.inset));}
  function clip(name){if(canAnimate())onClip(name);}
  function beginExit(){onStop();phase='exiting';progress=0;start.copy(actor.position);splashSent=false;speed=0;clip('Swim');onMessage('游回岸边，准备上岸。');}
  function request(point){
    if(contains(point)){
      goal=clampGoal(point);afterExit=null;
      if(phase==='exiting')afterExit=()=>request(point);
      if(phase==='land'){
        const plan=walkTo(entry.land);if(!plan?.ok){onMessage('岸边暂时过不去，换个位置再试试。');return {handled:true,plan};}
        phase='approaching';onMessage('去岸边，准备下水。');return {handled:true,plan};
      }
      if(phase==='swimming'){onStop();clip('Swim');}
      return {handled:true,plan:{ok:true,goal:{x:goal.x,z:goal.z},waypoints:[],swimming:true}};
    }
    if(phase==='land'||phase==='approaching'){phase='land';goal=null;return {handled:false};}
    afterExit=()=>walkTo(point);
    if(phase==='swimming')beginExit();
    return {handled:true,plan:{ok:true,goal:{x:point.x,z:point.z},waypoints:[],swimming:true}};
  }
  function update(delta){
    clock+=delta;
    if(phase==='approaching'&&!isWalking()){
      if(actor.position.distanceTo(entry.land)>.08){reset();return;}
      phase='entering';progress=0;start.copy(actor.position);onStop();clip('Swim');splashSent=false;
    }
    if(phase==='entering'||phase==='exiting'){
      progress=Math.min(1,progress+delta/(phase==='entering'?.95:1.15));
      const end=phase==='entering'?entry.water:entry.land;
      const t=THREE.MathUtils.smoothstep(progress,0,1);
      actor.position.lerpVectors(start,end,t);
      actor.position.y+=Math.sin(progress*Math.PI)*.065;
      actor.position.y=Math.max(actor.position.y,(groundHeight(actor.position.x,actor.position.z)??actor.position.y)+.005);
      desired.setFromAxisAngle(up,Math.atan2(end.x-start.x,end.z-start.z));actor.quaternion.rotateTowards(desired,5*delta);
      if(!splashSent&&progress>.5){onSplash(actor.position);splashSent=true;}
      if(progress===1){
        if(phase==='entering'){
          phase='swimming';onMessage('下水啦！点水面游泳，点草地上岸。');
          if(afterExit)beginExit();
        }else{
          phase='land';goal=null;clip('Idle');const next=afterExit;afterExit=null;
          if(next)next();else onMessage('回到岸上啦。');
        }
      }
      return;
    }
    if(phase!=='swimming')return;
    actor.position.y=waterY+Math.sin(clock*2.6)*.008;
    if(!canAnimate())return;
    const distance=goal?actor.position.clone().setY(waterY).distanceTo(goal):0;
    if(distance>.015){
      speed=THREE.MathUtils.damp(speed,.65,5,delta);
      const direction=goal.clone().sub(actor.position);direction.y=0;direction.normalize();
      desired.setFromAxisAngle(up,Math.atan2(direction.x,direction.z));actor.quaternion.rotateTowards(desired,4*delta);
      actor.position.addScaledVector(direction,Math.min(distance,speed*delta));clip('Swim');
    }else{goal=null;speed=0;clip('SwimIdle');}
  }
  function reset(){phase='land';goal=null;afterExit=null;progress=0;speed=0;}
  return {request,update,reset,contains,hold:()=>{if(phase==='swimming'){goal=null;speed=0;}},
    leave(callback){if(phase==='land')return false;afterExit=callback;if(phase==='approaching'){reset();callback();}else if(phase==='swimming')beginExit();return true;},
    get inWater(){return ['swimming','entering','exiting'].includes(phase);},get busy(){return phase==='entering'||phase==='exiting';},
    get moving(){return phase==='swimming'&&speed>.04;},
    debug:()=>({phase,progress,speed,goal:goal?.toArray()??null,entry:{land:entry.land.toArray(),water:entry.water.toArray()},waterY})};
}
