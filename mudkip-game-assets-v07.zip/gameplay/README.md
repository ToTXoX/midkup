# 庭院移动与碰撞 v0.7

打开 `resources.html?scene=garden` 进入庭院漫游。点击草地后，水跃鱼会转向并沿安全路线移动，到达后切回待机。可切换悠闲走和小跑、暂停、回到起点，拖动旋转镜头，滚轮或双指缩放。点到房屋、水池、树干或地面边缘时，终点会调整到附近可到达的草地。

## 接入

`garden-navigation.js` 不依赖 Three.js，可在网页游戏中单独复用。输入位置使用 `{x,z}` 或 `[x,z]`，单位为米。

```js
import {createGardenNavigation,createGardenWalker} from './gameplay/garden-navigation.js';

const navigation=createGardenNavigation(layout,{extraColliders});
const walker=createGardenWalker(navigation);
const plan=walker.start({x:actor.position.x,z:actor.position.z},clickedPoint);
// plan.ok、plan.adjusted、plan.goal 和 plan.waypoints 可用于终点和路线提示。

// 每帧：朝向 walker.waypoint，并让动画速度与地面速度一致。
const result=walker.advance(actor.position,speed*deltaSeconds);
actor.position.x=result.position.x;
actor.position.z=result.position.z;
// Y 由 NAV_Ground 的实际地表高度 + 0.005 米确定。
// result.finished 时切回 Idle；切换动作或场景时 walker.cancel()。
```

22 个关卡障碍包括房屋墙体、13 段栅栏、7 棵主要树木与水池。运行时自动增加三种靶子的占地；测试页根据 `Basket` 网格补充一个树果篮障碍，共 26 个。小草、花朵、低矮灌木作为装饰不参与阻挡。

使用 0.4 米的圆形角色占地与 0.04 米余量；水池额外预留 0.12 米岸边距离。角色尾鳍作为柔性外观，不单独计算刚体碰撞。碰撞沿完整移动线段检测，不依靠仅检查终点，较大的时间步也不会穿越细栅栏或墙体。房屋按矩形、树木和靶子按圆形、水池按外包椭圆多边形计算，并为角色尺寸扩张。

可直接到达时走直线；有障碍时在约 0.16 米网格上进行 A* 寻路，再按精确碰撞检测简化路线。对角移动检查完整线段，避免切过障碍角。不可达的点击位置会改到当前连通区域内的附近位置，不会隔着障碍传送。

`layout.navigation` 保存半径、余量、寻路格距与岸边距离。`walkableBounds` 是地面的保守范围，运行时还会根据角色占地进一步内缩。该版本处理静态地面障碍，未包含跳跃、游泳或移动靶子的动态避障。
