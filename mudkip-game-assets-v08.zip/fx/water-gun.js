import * as THREE from 'three';

const UP = new THREE.Vector3(0, 1, 0);
const GRAVITY = 20;
const SPEED = 9.0;
const JET_RADIUS = .052;
const SPLASH_SCALE = 1.55;
const SLICES = 42;
const SIDES = 14;
const clamp = THREE.MathUtils.clamp;
const smooth = THREE.MathUtils.smoothstep;

export function waterMaterial(opacity = 1) {
  return new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, side: THREE.FrontSide,
    uniforms: {
      uOpacity: { value: opacity },
      uStreak: { value: 0 },
      uClock: { value: 0 },
      uBody: { value: new THREE.Color('#B6E3E9') },
      uEdge: { value: new THREE.Color('#84BDC9') },
      uLight: { value: new THREE.Color('#F3FCFF') },
    },
    vertexShader: `
      varying vec3 vNormal;
      varying vec3 vView;
      varying vec2 vWaterUv;
      void main() {
        vec4 mv = modelViewMatrix * vec4(position, 1.0);
        vNormal = normalize(normalMatrix * normal);
        vView = -mv.xyz;
        vWaterUv=uv;
        gl_Position = projectionMatrix * mv;
      }`,
    fragmentShader: `
      uniform float uOpacity;
      uniform vec3 uBody;
      uniform vec3 uEdge;
      uniform vec3 uLight;
      uniform float uStreak;
      uniform float uClock;
      varying vec3 vNormal;
      varying vec3 vView;
      varying vec2 vWaterUv;
      void main() {
        vec3 n = normalize(vNormal);
        vec3 v = normalize(vView);
        vec3 l = normalize((viewMatrix * vec4(-0.45, 0.85, 0.55, 0.0)).xyz);
        float rim = pow(1.0 - max(0.0, dot(n, v)), 2.0);
        float diffuse = smoothstep(0.22,0.25,dot(n,l));
        float highlight = smoothstep(0.965,0.980,max(0.0,dot(n,normalize(l+v))));
        float ink = smoothstep(0.56,0.72,rim);
        vec3 color = mix(uBody,uEdge,ink*0.7)*(0.86+0.14*diffuse);
        color = mix(color,uLight,highlight*0.84);
        float band = 1.0-smoothstep(0.018,0.055,abs(vWaterUv.y-0.74));
        float lengthMask=smoothstep(0.07,0.18,vWaterUv.x)*(1.0-smoothstep(0.62,0.84,vWaterUv.x));
        color=mix(color,uLight,band*lengthMask*uStreak*(0.82+0.12*sin(vWaterUv.x*18.0-uClock*28.0)));
        gl_FragColor = vec4(color, uOpacity * mix(0.64, 0.88, rim));
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
  });
}

function streamGeometry() {
  const geometry = new THREE.BufferGeometry();
  const positions = new Float32Array((SLICES + 1) * (SIDES + 1) * 3);
  const uv=new Float32Array((SLICES+1)*(SIDES+1)*2);
  const indices = [];
  for (let i = 0; i < SLICES; i++) for (let j = 0; j < SIDES; j++) {
    const a = i * (SIDES + 1) + j, b = a + SIDES + 1;
    indices.push(a, a + 1, b, a + 1, b + 1, b);
  }
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3).setUsage(THREE.DynamicDrawUsage));
  for(let i=0;i<=SLICES;i++)for(let j=0;j<=SIDES;j++){const index=(i*(SIDES+1)+j)*2;uv[index]=i/SLICES;uv[index+1]=j/SIDES;}
  geometry.setAttribute('uv',new THREE.BufferAttribute(uv,2));
  geometry.setIndex(indices);
  return geometry;
}

function dropletGeometry() {
  return new THREE.LatheGeometry([
    new THREE.Vector2(0, -1.4), new THREE.Vector2(.12, -.95),
    new THREE.Vector2(.5, -.25), new THREE.Vector2(.72, .18),
    new THREE.Vector2(.65, .58), new THREE.Vector2(.35, .88),
    new THREE.Vector2(0, 1.0),
  ], 12);
}

function splashLobeGeometry() {
  const shape=new THREE.Shape();
  shape.moveTo(-.018,0);
  shape.bezierCurveTo(-.005,.045,.045,.140,.105,.130);
  shape.bezierCurveTo(.133,.125,.143,.100,.121,.087);
  shape.bezierCurveTo(.078,.079,.060,.025,.067,.002);
  shape.quadraticCurveTo(.025,-.006,-.018,0);
  const geometry=new THREE.ExtrudeGeometry(shape,{depth:.009,bevelEnabled:true,bevelThickness:.003,bevelSize:.003,bevelSegments:2,steps:1,curveSegments:8});
  geometry.translate(0,0,-.0045);
  const highlight=new THREE.Shape();
  highlight.moveTo(.022,.040);
  highlight.bezierCurveTo(.041,.094,.083,.134,.110,.116);
  highlight.bezierCurveTo(.081,.120,.049,.083,.031,.039);
  highlight.closePath();
  return {body:geometry,highlight:new THREE.ShapeGeometry(highlight,10)};
}

function createCartoonSplash() {
  const group=new THREE.Group();
  group.name='Cartoon impact burst';
  const geometry=splashLobeGeometry();
  const lobes=Array.from({length:4},(_,i)=>{
    const root=new THREE.Group();
    const material=new THREE.MeshBasicMaterial({color:'#AADCE5',transparent:true,opacity:.92,depthWrite:false,toneMapped:false});
    const body=new THREE.Mesh(geometry.body,material);
    const white=new THREE.MeshBasicMaterial({color:'#F1FCFF',transparent:true,opacity:.9,depthWrite:false,side:THREE.DoubleSide,toneMapped:false});
    const front=new THREE.Mesh(geometry.highlight,white);
    const back=new THREE.Mesh(geometry.highlight,white);
    front.position.z=.009;back.position.z=-.009;
    root.add(body,front,back);group.add(root);
    return {root,material,white,angle:[.32,2.03,3.69,5.26][i],birth:[0,.018,.103,.127][i],size:[1,.78,.88,.66][i]};
  });
  const patch=new THREE.Mesh(new THREE.CircleGeometry(1,48),new THREE.MeshBasicMaterial({color:'#D0EDF1',transparent:true,opacity:.40,depthWrite:false,side:THREE.DoubleSide,toneMapped:false}));
  patch.rotation.x=-Math.PI/2;patch.position.y=.003;
  const p=patch.geometry.attributes.position;
  for(let i=0;i<p.count;i++){
    const angle=Math.atan2(p.getY(i),p.getX(i));
    const radius=1+.14*Math.sin(angle*5+.4)+.06*Math.sin(angle*3);
    p.setX(i,p.getX(i)*radius);p.setY(i,p.getY(i)*radius);
  }
  group.add(patch);
  return {group,update(age,contactEnd){
    let active=0;
    for(const lobe of lobes){
      const t=age-lobe.birth,life=.21;
      lobe.root.visible=t>=0&&t<life;
      if(!lobe.root.visible)continue;
      active++;
      const u=t/life,open=1-Math.pow(1-u,3);
      const height=Math.pow(Math.sin(Math.PI*u),.68);
      const distance=.008+.15*open;
      lobe.root.position.set(Math.cos(lobe.angle)*distance,.003,Math.sin(lobe.angle)*distance);
      lobe.root.rotation.y=-lobe.angle;
      lobe.root.scale.set((.38+.68*open)*lobe.size,height*lobe.size,(1-.62*u)*lobe.size);
      const fade=1-smooth(u,.70,1);
      lobe.material.opacity=.92*fade;lobe.white.opacity=.9*fade;
    }
    const grow=1-Math.exp(-age/.025);
    patch.visible=age<contactEnd+.14;
    patch.scale.set((.065+.060*grow)*(1+.04*Math.sin(age*28)),.052+.050*grow,1);
    patch.material.opacity=.40*(1-smooth(age,contactEnd,contactEnd+.14));
    group.visible=active>0||patch.visible;
    return {lobes:active,patch:patch.visible};
  }};
}

function irregularRing() {
  const geometry = new THREE.RingGeometry(.977, 1, 90);
  geometry.rotateX(-Math.PI / 2);
  const p = geometry.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const a = Math.atan2(p.getZ(i), p.getX(i));
    const wobble = 1 + .035 * Math.sin(a * 3) + .018 * Math.sin(a * 5 + .7);
    p.setXYZ(i, p.getX(i) * wobble, 0, p.getZ(i) * wobble);
  }
  return geometry;
}

/** A deterministic, pooled effect: action time can be scrubbed in either direction. */
export function createWaterGunEffect({ scene, resolveImpact, start=.33, stop=.66, actionDuration=1 }) {
  const START=start,STOP=stop;
  const group = new THREE.Group();
  group.name = 'Water gun — stream, droplets, impact and ripples';
  scene.add(group);
  const streams = Array.from({length:3},()=>{
    const mesh=new THREE.Mesh(streamGeometry(),waterMaterial());
    mesh.material.uniforms.uStreak.value=.85;
    mesh.frustumCulled=false;return mesh;
  });
  const head=new THREE.Mesh(new THREE.SphereGeometry(1,20,14),waterMaterial());
  const mouthBead = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 16), waterMaterial(.95));
  const impact = new THREE.Group();
  impact.name='Water impact';
  const splash=createCartoonSplash();
  const crown=splash.group;
  crown.scale.setScalar(SPLASH_SCALE);
  const wet = new THREE.Mesh(new THREE.CircleGeometry(1, 72), new THREE.MeshBasicMaterial({ color: '#548D83', transparent: true, depthWrite: false, opacity: .18, side: THREE.DoubleSide }));
  wet.rotation.x = -Math.PI / 2;
  wet.position.y = .001;
  const wetPositions = wet.geometry.attributes.position;
  for (let i = 0; i < wetPositions.count; i++) {
    const a = Math.atan2(wetPositions.getZ(i), wetPositions.getX(i));
    const wobble = 1 + .11 * Math.sin(a * 3 + 1) + .065 * Math.cos(a * 5);
    wetPositions.setX(i, wetPositions.getX(i) * wobble);
    wetPositions.setZ(i, wetPositions.getZ(i) * wobble);
  }
  const ripples = [0, 1].map(() => {
    const mesh = new THREE.Mesh(irregularRing(), new THREE.MeshBasicMaterial({ color: '#D1F6FF', transparent: true, depthWrite: false, side: THREE.DoubleSide }));
    mesh.position.y = .006;
    return mesh;
  });
  impact.add(wet,crown,...ripples);
  group.add(...streams,head,mouthBead, impact);
  const dropGeometry = dropletGeometry();
  const flightDrops = Array.from({ length: 7 }, () => new THREE.Mesh(dropGeometry, waterMaterial(.97)));
  const splashDrops = Array.from({ length: 4 }, () => new THREE.Mesh(dropGeometry, waterMaterial(.95)));
  group.add(...flightDrops, ...splashDrops);
  group.traverse((o) => { if (o.isMesh) { o.renderOrder = 4; o.castShadow = false; } });
  wet.renderOrder = 2;
  ripples.forEach((o) => o.renderOrder = 5);
  let pooledMeshes=0;group.traverse((o)=>{if(o.isMesh)pooledMeshes++;});
  let ready = false, lastTime = 0, tail = false;
  let flight = .28, firstImpact = .45, lastImpact = .74;
  let endTime=1.65;
  const origin = new THREE.Vector3(), velocity = new THREE.Vector3();
  const currentMouth = new THREE.Vector3(), frozenMouth = new THREE.Vector3();
  const neckOffset = new THREE.Vector3();
  const direction = new THREE.Vector3(), right = new THREE.Vector3();
  const hit = new THREE.Vector3(), hitNormal = new THREE.Vector3();
  const point = new THREE.Vector3(), before = new THREE.Vector3(), after = new THREE.Vector3();
  const tangent = new THREE.Vector3(), binormal = new THREE.Vector3();
  const radial = new THREE.Vector3(), dropVelocity = new THREE.Vector3();
  let current = { phase: 'idle', emitting: false, stream: false, crown: false, ripples: 0, flightDrops: 0, splashDrops: 0 };

  function hide() {
    group.visible = false;
    current = { phase: 'idle', emitting: false, stream: false, crown: false, ripples: 0, flightDrops: 0, splashDrops: 0 };
  }
  function reset() { ready = false; tail = false; lastTime = 0;hide(); }
  function initialize(position, forward) {
    ready = true;
    origin.copy(position);
    direction.copy(forward).normalize();
    velocity.copy(direction).multiplyScalar(SPEED);
    right.crossVectors(direction, UP).normalize();
    if (right.lengthSq() < .1) right.set(1, 0, 0);
    const result = resolveImpact(origin, velocity, GRAVITY);
    flight = result.time;
    hit.copy(result.point);
    hitNormal.copy(result.normal).normalize();
    firstImpact = START + flight;
    lastImpact = STOP + flight;
    endTime=lastImpact+.55;
    impact.position.copy(hit).addScaledVector(hitNormal, .002);
    const forwardOnSurface = direction.clone().addScaledVector(hitNormal, -direction.dot(hitNormal));
    if (forwardOnSurface.lengthSq() < .01) {
      forwardOnSurface.copy(Math.abs(hitNormal.y) < .9 ? UP : new THREE.Vector3(0,0,1));
      forwardOnSurface.addScaledVector(hitNormal,-forwardOnSurface.dot(hitNormal));
    }
    forwardOnSurface.normalize();
    const surfaceRight = new THREE.Vector3().crossVectors(hitNormal, forwardOnSurface).normalize();
    impact.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(surfaceRight, hitNormal, forwardOnSurface));
    frozenMouth.copy(position);
  }
  function path(age, target) {
    target.copy(origin).addScaledVector(velocity, age);
    target.y -= .5 * GRAVITY * age * age;
    // The thin neck follows the mouth. Water already in flight keeps its path.
    target.addScaledVector(neckOffset, Math.exp(-age / .035));
    target.addScaledVector(right, Math.sin(age * 27 - lastTime * 12) * .005 * Math.sin(Math.PI * age / flight));
    target.lerp(hit, smooth(age, flight - .02, flight));
    return target;
  }
  function placeDrop(mesh, position, motion, size, opacity = 1) {
    mesh.position.copy(position);
    mesh.quaternion.setFromUnitVectors(UP, motion.clone().normalize());
    const stretch = 1 + clamp(motion.length() / 6, 0, 1) * .85;
    mesh.scale.set(size, size * stretch, size);
    mesh.material.uniforms.uOpacity.value = opacity;
    mesh.visible = true;
  }
  function render(time) {
    lastTime = time;
    group.visible = time < endTime;
    streams.forEach((o)=>o.visible=false);
    head.visible = mouthBead.visible = impact.visible = false;
    flightDrops.forEach((o) => o.visible = false);
    splashDrops.forEach((o) => o.visible = false);
    if (time >= endTime) { tail = false; ready = false; hide(); return; }
    neckOffset.subVectors(currentMouth,origin);
    const emitting = time >= START && time < STOP;
    let maximumRadius=0;
    let nearMouthRadius=0;
    const youngest = Math.max(0, time - STOP);
    const oldest = Math.min(time - START, flight);
    if (time >= START-.025 && time < STOP + .035) {
      const swell = smooth(time, START-.025, START + .015) * (1 - smooth(time, STOP - .025, STOP + .035));
      mouthBead.visible = swell > .001;
      mouthBead.position.copy(currentMouth).addScaledVector(direction, .007);
      mouthBead.scale.set(.013 * swell, .011 * swell, .020 * swell);
      mouthBead.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), direction);
    }
    if (oldest - youngest > .006 && oldest > 0) {
      const breakup=smooth(time,STOP+.035,STOP+.13);
      const span=oldest-youngest,gap=breakup*.042*span;
      const ranges=breakup>.01?[[youngest,youngest+span*.24-gap],[youngest+span*.24+gap,youngest+span*.67-gap*.7],[youngest+span*.67+gap*.7,oldest]]:[[youngest,oldest]];
      ranges.forEach(([minAge,maxAge],part)=>{
      if(maxAge-minAge<.006)return;
      const stream=streams[part];stream.visible=true;
      stream.material.uniforms.uClock.value=time;
      const positions = stream.geometry.attributes.position;
      for (let i = 0; i <= SLICES; i++) {
        const u = i / SLICES, age = THREE.MathUtils.lerp(minAge, maxAge, u);
        path(age, point);
        path(Math.max(0, age - .001), before);
        path(age + .001, after);
        tangent.subVectors(after, before).normalize();
        binormal.crossVectors(tangent, right).normalize();
        const waves = 1 + .12 * Math.sin(age * 43 - time * 22) + .075 * Math.sin(age * 71 + .8);
        const along=(age-youngest)/span;
        const bulge = .030 * Math.exp(-Math.pow((along - .88) / .14, 2));
        const cap=Math.sqrt(clamp(Math.min(age-minAge,maxAge-age)/.008,0,1));
        const flare=.18+.87*smooth(age,.010,.075);
        const radius = (JET_RADIUS * waves * flare + bulge) * cap * Math.min(1, span / .035);
        maximumRadius=Math.max(maximumRadius,radius);
        if(emitting&&age<=.020)nearMouthRadius=Math.max(nearMouthRadius,radius);
        for (let j = 0; j <= SIDES; j++) {
          const angle = j / SIDES * Math.PI * 2;
          radial.copy(right).multiplyScalar(Math.cos(angle)).addScaledVector(binormal, Math.sin(angle)*.82);
          positions.setXYZ(i * (SIDES + 1) + j, point.x + radial.x * radius, point.y + radial.y * radius, point.z + radial.z * radius);
        }
      }
      positions.needsUpdate = true;
      stream.geometry.computeVertexNormals();
      });
      if(time<firstImpact){
        head.visible=true;
        path(Math.max(0,oldest-.004),head.position);
        tangent.copy(velocity);tangent.y-=GRAVITY*oldest;tangent.normalize();
        head.quaternion.setFromUnitVectors(new THREE.Vector3(0,0,1),tangent);
        const radius=.075*Math.min(1,span/.035);
        head.scale.set(radius*1.35,radius*.90,radius);
      }
    }
    flightDrops.forEach((mesh, i) => {
      const birth = START + .026 + i * .035, age = time - birth;
      if (age < 0 || age > .40) return;
      const seedAge = .043 + (i % 3) * .018;
      point.copy(origin).addScaledVector(velocity, seedAge);
      point.y -= .5 * GRAVITY * seedAge * seedAge;
      dropVelocity.copy(velocity).multiplyScalar(.8 + (i % 3) * .045).addScaledVector(right, Math.sin(i * 2.4) * .64);
      dropVelocity.y += .10 + Math.cos(i * 1.7) * .27 - GRAVITY * seedAge;
      point.addScaledVector(dropVelocity, age);
      point.y -= .5 * GRAVITY * age * age;
      if (point.y < hit.y + .009 && hitNormal.y > .6) return;
      dropVelocity.y -= GRAVITY * age;
      placeDrop(mesh, point, dropVelocity, .016 + ((i * 7) % 5) * .0025, 1 - smooth(age, .30, .40));
    });
    const impactAge = time - firstImpact;
    let splashState={lobes:0,patch:false};
    if (impactAge >= 0) {
      impact.visible = true;
      splashState=splash.update(impactAge,lastImpact-firstImpact);
      wet.scale.setScalar(.14+.12*smooth(impactAge,0,.35));
      wet.material.opacity=.08*(1-smooth(time,lastImpact+.08,endTime));
      ripples.forEach((mesh, i) => {
        const age = impactAge - .035 - i * .11, duration = .48;
        mesh.visible = age >= 0 && age < duration;
        if (!mesh.visible) return;
        const u = age / duration;
        const radius = .09 + .35 * (1 - Math.pow(1 - u, 2));
        mesh.scale.set(radius, 1, radius * .94);
        mesh.material.opacity = .48 * Math.pow(1 - u, 1.6);
      });
      splashDrops.forEach((mesh, i) => {
        const age = impactAge - .008 * i;
        if (age < 0 || age > .30) return;
        const angle = i * 2.399 + .25;
        const localVelocity = new THREE.Vector3(Math.cos(angle) * (1.05 + (i % 3) * .17), 1.08 + (i % 3) * .16, Math.sin(angle) * (1.05 + (i % 3) * .17));
        dropVelocity.copy(localVelocity).applyQuaternion(impact.quaternion);
        point.copy(hit).addScaledVector(dropVelocity, age);
        point.y -= .5 * GRAVITY * age * age;
        if (point.clone().sub(hit).dot(hitNormal) < 0) return;
        dropVelocity.y -= GRAVITY * age;
        placeDrop(mesh, point, dropVelocity, .023 + (i % 3) * .004, 1 - smooth(age, .15, .26));
      });
    }
    current = {
      phase: time < START ? 'anticipation' : emitting ? 'jet' : time < lastImpact ? 'cutoff' : crown.visible ? 'splash' : 'residual',
      emitting, mouthBead:mouthBead.visible, stream: streams.some((o)=>o.visible), fragments:streams.filter((o)=>o.visible).length,crown: impact.visible && crown.visible,
      ripples: impact.visible ? ripples.filter((o) => o.visible).length : 0,
      flightDrops: flightDrops.filter((o) => o.visible).length,
      splashDrops: splashDrops.filter((o) => o.visible).length,
      impactPoint: hit.toArray(), impactNormal: hitNormal.toArray(), firstImpact, lastImpact,
      time, youngestAge: youngest, oldestAge: oldest,
      splashStyle:'simple-cartoon',splashLobes:splashState.lobes,contactPatch:splashState.patch,
      maximumDiameter:maximumRadius*2,jetSpeed:SPEED,splashScale:SPLASH_SCALE,
      nearMouthDiameter:nearMouthRadius*2,
    };
  }
  reset();
  return {
    begin(position,forward) { reset();if(position&&forward)initialize(position,forward); },
    cancel: reset,
    finish: () => { tail = ready; lastTime = actionDuration; },
    update(time, position, forward) {
      if (!ready) initialize(position, forward);
      if (time <= STOP) frozenMouth.copy(position);
      currentMouth.copy(time <= STOP ? position : frozenMouth);
      render(time);
    },
    updateTail(delta) { if (tail) render(lastTime + delta); },
    debug: () => ({ ...current, active: group.visible, tail, pooledMeshes, streamVertices: streams[0].geometry.attributes.position.count }),
    dispose() {
      scene.remove(group);
      const geometries = new Set(), materials = new Set();
      group.traverse((o) => { if (o.isMesh) { geometries.add(o.geometry); materials.add(o.material); } });
      geometries.forEach((g) => g.dispose()); materials.forEach((m) => m.dispose());
    },
  };
}
