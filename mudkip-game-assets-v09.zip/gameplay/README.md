# 庭院移动、瞄准与水枪 v0.9

## 水枪练习

庭院默认使用移动模式。点击靶子即切换瞄准模式并锁定靶心，先转身再抬头；按空格或「喷水」发射。按 Esc 或点击「移动」退出瞄准。瞄准模式下点击草地可选择自由落点。手机可点击靶子附近 36 像素触控区，并使用屏幕喷水按钮。

准星主体为四角与中心点，没有轨迹线。标签提示可命中、距离太远或被遮挡；远处目标需要先移动靠近，不会自动寻路接近目标。当前三个靶子均静止，滑轨靶的往复移动属于后续工作。

`water-aim.js` 的 `solveWaterAim(origin,point)` 返回 `direction`、`angle`、`range`、`time`、`reachable`。使用与效果相同的初速度 9 米/秒、重力 20 米/秒²，选择低弧线。上限为 4.4 米，实际射程还受目标高度与弹道判别式限制。无法到达时仍可朝该方向喷水，按真实落点处理，不会强制吸附命中。

`garden-combat.js` 的 `createGardenCombat({actor,model,preview,onShoot,onStop,onMessage,onHit})` 提供：

- `setMode('move'|'aim')`、`aimAt(worldPoint,targetId)`、`fire(paused)`、`cancel()`。
- 每帧先调用 `update(delta)` 转身及启动单次施法，再更新 `AnimationMixer`，之后调用 `pose()` 叠加头部瞄准。不要在未刷新动画的同一姿态上重复调用 `pose()`。
- `onShoot(point,id)` 应播放 `WaterShoot` 并把本次点位与编号交给水流系统；`onStop()` 停止移动和旧效果。`onActionChange(name,{completed})` 同步恢复或打断状态；`contact({shotId,targetId,point,time})` 只接收本次发射的真实接触事件。
- `preview.traceWater(origin,direction)` 必须按水流的相同速度、重力和场景几何返回首个接触；`preview.targetPoint(id)` 返回世界靶心。测试页的实现见 `animation-test/src/resource-preview.js`。

游戏发射采用 `water.begin(null,null,{defer:true})`，在动作 0.33 秒真正出水时读取嘴部位置、求解并冻结这一发弹道。此后薄水颈跟随嘴部，已飞出的水保留轨迹。碰撞以 0.02 秒弧线片段对真实模型做射线检测；碰撞点、法线、靶子编号同时供水花与计分使用。只有靶盘、彩环、靶心可计分，底座与立柱不算靶面。第一股水抵达后每发只计一次，选中目标本身不计分。

`target-feedback.js` 的 `createTargetFeedback(records)` 接收 `{id,object,hit:{center,radius}}`，并提供 `hit(id)`、`update(delta)`、`reset()`、`debug()`。靶板和立柱围绕底座上方回弹，底座留在原处；重型靶摆动较小。命中闪光持续 0.33 秒，弹性摆动在 0.8 秒内结束，界面「命中 +1」在 0.75 秒内上浮消失。暂停时传零 delta。材质与几何体在初始化时创建并重复使用。

`npm run test:combat` 检查物理落点、实际点击与空格、准备与飞行阶段、三个靶子、一次计分、打空和墙体、移动打断、暂停、触控及多次施法资源复用。结果写入 `docs/garden-combat-v09-tests.json`。

## 移动与碰撞

打开 `resources.html?scene=garden` 进入庭院漫游。点击草地后，水跃鱼会转向并沿安全路线移动，到达后切回待机。可切换轻快走和小跑、暂停、回到起点，拖动旋转镜头，滚轮或双指缩放。点到房屋、水池、树干或地面边缘时，终点会调整到附近可到达的草地。

走路约 0.66 米/秒，小跑约 1.54 米/秒。走路周期 0.5 秒，跑步周期 0.4 秒；位移和动画播放速度随加减速一致变化。转弯加入最多约 5° 的轻微侧倾，停步后回正。路径在内部用于绕行，画面显示白边薄荷绿落点环，不绘制指示线。

## 接入

`garden-navigation.js` 不依赖 Three.js，可在网页游戏中单独复用。输入位置使用 `{x,z}` 或 `[x,z]`，单位为米。

```js
import {createGardenNavigation,createGardenWalker} from './gameplay/garden-navigation.js';

const navigation=createGardenNavigation(layout,{extraColliders});
const walker=createGardenWalker(navigation);
const plan=walker.start({x:actor.position.x,z:actor.position.z},clickedPoint);
// plan.ok、plan.adjusted、plan.goal 和 plan.waypoints 用于终点与路径跟随。

// 每帧：朝向 walker.waypoint，按 remainingDistance() 规划减速，动画速度与地面速度一致。
const result=walker.advance(actor.position,speed*deltaSeconds);
actor.position.x=result.position.x;
actor.position.z=result.position.z;
// Y 由 NAV_Ground 的实际地表高度 + 0.005 米确定。
// result.finished 时切回 Idle；切换动作或场景时 walker.cancel()。
```

`destination-marker.js` 提供 `createDestinationMarker(scene)`，通过 `show(worldPosition)`、`arrive()`、`hide()` 控制落点；每帧调用 `update(deltaSeconds,camera,viewportHeight)`。圆环主体以约 36 个 CSS 像素为目标，带白边后约 40 像素，自动适配视角和屏幕。点击时弹出并扩散一道细环，等待期间轻微呼吸，到达后在 0.28 秒内收拢淡出。暂停时传入零 delta。几何体和材质在初始化时创建并复用。

22 个关卡障碍包括房屋墙体、13 段栅栏、7 棵主要树木与水池。运行时自动增加三种靶子的占地；测试页根据 `Basket` 网格补充一个树果篮障碍，共 26 个。小草、花朵、低矮灌木作为装饰不参与阻挡。

使用 0.4 米的圆形角色占地与 0.04 米余量；水池额外预留 0.12 米岸边距离。角色尾鳍作为柔性外观，不单独计算刚体碰撞。碰撞沿完整移动线段检测，不依靠仅检查终点，较大的时间步也不会穿越细栅栏或墙体。房屋按矩形、树木和靶子按圆形、水池按外包椭圆多边形计算，并为角色尺寸扩张。

可直接到达时走直线；有障碍时在约 0.16 米网格上进行 A* 寻路，再按精确碰撞检测简化路线。对角移动检查完整线段，避免切过障碍角。不可达的点击位置会改到当前连通区域内的附近位置，不会隔着障碍传送。

`layout.navigation` 保存半径、余量、寻路格距与岸边距离。`walkableBounds` 是地面的保守范围，运行时还会根据角色占地进一步内缩。该版本处理静态地面障碍，未包含跳跃、游泳或移动靶子的动态避障。
